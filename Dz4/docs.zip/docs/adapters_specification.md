# Документация: Слой адаптеров (Adapter Layer) — Подробная спецификация

> **Версия:** v5.0  
> **Последнее обновление:** 2026-09-04  
> **См. также:** [ADR-012](../05_adr_log.md) — Архитектурное решение о введении слоя адаптеров

---

## 1. Обзор слоя адаптеров

Слой адаптеров — это уровень абстракции, который изолирует ядро системы от конкретных инфраструктурных компонентов. Взаимодействие с хранилищем, LLM, эмбеддером и реранкером происходит исключительно через программные интерфейсы.

### 1.1. Цели

- **Гибкость:** Замена любого компонента — правка одного конфига, без переписывания ядра.
- **Расширяемость:** Сторонние разработчики могут создавать свои адаптеры через entry_points.
- **Снижение vendor lock-in:** Нет жёсткой привязки к конкретному поставщику.
- **Выбор стека:** Подбор оптимальной конфигурации под задачу (лёгкая инсталляция, облачный LLM, замена хранилища).

### 1.2. Архитектурная роль

```
+----------------------------------------------------------+
|                    ЯДРО СИСТЕМЫ (fixed)                   |
|                                                           |
|  Ingestion Pipeline                                       |
|  Retriever                                                |
|  Services                                                 |
|                                                           |
|  Вызывает методы интерфейсов:                              |
|    storage.query()                                        |
|    llm.generate()                                         |
|    embeddings.embed_batch()                               |
|    reranker.rerank()                                      |
+----------------------------------------------------------+
                                 |
                                 | программный интерфейс (ABC)
                                 v
+----------------------------------------------------------+
|               СЛОЙ АДАПТЕРОВ (runtime config)             |
|                                                           |
|  GraphStorage (ABC)                                       |
|  LLMInference (ABC)                                       |
|  Embedder (ABC)                                           |
|  Reranker (ABC)                                           |
|                                                           |
+----------------------------------------------------------+
                                 |
                                 | конкретная реализация
                                 v
+----------------------------------------------------------+
|             КОНКРЕТНЫЕ РЕАЛИЗАЦИИ (adapters.yaml)         |
|                                                           |
|  Neo4jAdapter / QdrantStorageAdapter / MemgraphAdapter    |
|  OllamaAdapter / OpenAICompatibleAdapter / VllmAdapter    |
|  BgeM3ServiceAdapter / LocalSentenceTransformerAdapter    |
|  BgeRerankerAdapter / NoOpRerankerAdapter                 |
+----------------------------------------------------------+
```

---

## 2. Интерфейс GraphStorage

### 2.1. Описание

Абстракция для работы с хранилищем графа и векторов. Ядро не знает, какая СУБД используется — Neo4j, Qdrant, Memgraph или другая.

### 2.2. Контракт (Abstract Base Class)

```python
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

class GraphStorage(ABC):
    @abstractmethod
    def query(self, cypher_or_gremlin: str, params: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """Выполнение графового запроса."""
        ...

    @abstractmethod
    def vector_search(self, embedding: List[float], top_k: int = 5) -> List[Dict[str, Any]]:
        """Векторный поиск ближайших чанков."""
        ...

    @abstractmethod
    def upsert_nodes(self, nodes: List[Dict[str, Any]]) -> None:
        """Массовая вставка/обновление узлов."""
        ...

    @abstractmethod
    def upsert_edges(self, edges: List[Dict[str, Any]]) -> None:
        """Массовая вставка/обновление рёбер."""
        ...

    @abstractmethod
    def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Получение узла по ID."""
        ...

    @abstractmethod
    def delete_node(self, node_id: str) -> bool:
        """Удаление узла по ID."""
        ...
```

### 2.3. Реализации

#### 2.3.1. Neo4jAdapter (базовая)

- **Драйвер:** Neo4j Bolt-драйвер (официальный).
- **Язык запросов:** Cypher.
- **Векторный поиск:** Нативный векторный индекс Neo4j.
- **Конфигурация:**
  ```yaml
  adapters:
    storage: "neo4j"
  storage:
    neo4j_uri: "bolt://neo4j:7687"
    vector_index: "chunk_embeddings"
  ```

#### 2.3.2. Neo4jGrpcAdapter

- **Драйвер:** gRPC-драйвер для production-кластеров Neo4j.
- **Преимущество:** Выше пропускная способность, кластерная маршрутизация.
- **Конфигурация:**
  ```yaml
  adapters:
    storage: "neo4j_grpc"
  ```

#### 2.3.3. MemgraphAdapter

- **Драйвер:** Bolt-совместимый драйвер Memgraph.
- **Язык запросов:** Cypher.
- **Причина выбора:** Лицензия Apache 2.0 (без GPLv3), ниже потребление ОЗУ.
- **Конфигурация:**
  ```yaml
  adapters:
    storage: "memgraph"
  ```

#### 2.3.4. QdrantStorageAdapter

- **Тип:** Только векторы + метаданные (без графа).
- **Причина выбора:** Горизонтальное масштабирование векторного поиска.
- **Ограничение:** Графовые запросы не поддерживаются. При использовании данного адаптера Graph Retriever отключается.
- **Конфигурация:**
  ```yaml
  adapters:
    storage: "qdrant"
  ```

### 2.4. Ограничения

- При замене хранилища необходима миграция данных.
- При замене на Qdrant — Graph Retriever недоступен (только Vector Retriever).